age = 20;

marks = 98;

function addThreeNumbers(a, b, c) {
    return a * b * c;
}

let c = addThreeNumbers(5, 5, 5);


isfollow = true;
name = "kundan";
Number = 90;
fullName = "ranjan";
fullName = "raj"

let price = 99;
var fullName = "kundan";
var fullname = "raj"

{
    company = "Amazon";

    company = "Filpkart"


}
console.log(company);

{
    let a = 10;
    console.log(a)

}

{
    let age = 25;
    console.log(age)

}

const PI = 3.14;
console.log(PI);

isfollow = true;
isFollow = false;

//*let x=null;*//

let marks=98;
console.log(marks);

let y=symbol("Hello!");

