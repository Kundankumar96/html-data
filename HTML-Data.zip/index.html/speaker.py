import speech_recognition as sr

def listen():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        recognizer.adjust_for_ambient_noise(source)  # Adjust for noise
        audio = recognizer.listen(source)

    try:
        
        print("Recognizing...")
        text = recognizer.recognize_google(audio)
        return text
    except sr.UnknownValueError:
        print("Sorry, I couldn't understand what you said.")
    except sr.RequestError:
        print("Sorry, I couldn't access the speech recognition service.")
    return ""

def main():
    while True:
        command = listen().lower()
        if "hello" in command:
            print("Hi there!")
        elif "goodbye" in command:
            print("Goodbye!")
            break
        else:
            print("I'm not sure what you want.")

if __name__ == "__main__":
    main()
